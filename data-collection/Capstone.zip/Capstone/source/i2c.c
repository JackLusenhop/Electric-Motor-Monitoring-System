/*
 * i2c.c
 *
 *  Created on: Mar 25, 2024
 *      Author: jacklusenhop
 */
#include <stdio.h>
#include "board.h"
#include "peripherals.h"
#include "pin_mux.h"
#include "clock_config.h"
#include "MKL46Z4.h"
#include "fsl_debug_console.h"

void clearStatusFlags()
{
    // Clear STOPF and Undocumented STARTF bit 4 in Filter Register
	I2C0->FLT = 0x50;

    // Clear ARBL and IICIF bits in Status Register
	I2C0->S |= (0x1 << 4) | (0x1 << 1);
}

void TCFWait()
{
    while(!(I2C0->S & 1<<7)) {}
}


void IICIFWait()
{
    while(!(I2C0->S & 1<<1)) {}
}

void SendStart()
{
    // Set MST and TX bits in Control 1 Register
	I2C0->C1 |= (1<<5) | (1<<4);
}

void RepeatStart()
{
    // Set MST, TX and RSTA bits in Control 1 Register
	I2C0->C1 |= 0x34;

    // Wait 6 cycles
	unsigned int i = 0;
	while(i < 6){i++;}
}

void SendStop()
{
    // Clear MST, TX and TXAK bits in Control 1 Register
	I2C0->C1 &= 0xC8;

    // Wait for BUSY bit to go low in Status Register
	while(I2C0->S & 0x20) {}
}

void clearIICIF()
{
    // Clear IICIF bit in Status Register
	I2C0->S |= 1 << 1;
}

int RxAK()
{
    // Return 1 if byte has been ACK'd. (See RXAK in Status Register)
	return !(I2C0->S & 0x1);
}

void I2C_writeByte(char register_address, char data)
{
	unsigned char dummy = 0;
    clearStatusFlags();
    TCFWait();
    SendStart();

    dummy++;

    // TODO: Write Device Address, R/W = 0 to Data Register
    I2C0->D = register_address << 1;

    IICIFWait();

    if (!RxAK()){
        printf("NO RESPONSE - Address");
        SendStop();
        return;
    }
    clearIICIF();

    // Write Data byte to Data Register
    I2C0->D = data;

    IICIFWait();
    if (!RxAK()){
        printf("Incorrect ACK - Data");
    }
    clearIICIF();
    SendStop();
}

void I2C_readBlock(unsigned char device_addr, unsigned char* destination, int length)
{
	unsigned char dummy = 0;
	clearStatusFlags();
    TCFWait();
    SendStart();

    dummy++;

    // Write device, R/W = 1 to Data Register
    I2C0->D = device_addr << 1 | 0x1;

    IICIFWait();

    if (!RxAK()){
        printf("NO RESPONSE - Restart");
        SendStop();
        return;
    }

    TCFWait();
    clearIICIF();

    // Switch to RX by clearing TX and TXAK bits in Control 1 register
    I2C0->C1 &= ~((1<<3) | (1<<4));

    if(length==1){
        // Set TXAK to NACK in Control 1 - No more data!
    	I2C0->C1 |= (0x1 << 3);
    }

   dummy = I2C0->D; // Dummy Read

    for(int index=0; index<length; index++){
        IICIFWait();
        clearIICIF();

        if(index == length - 2){
            // Set TXAK to NACK in Control 1 - No more data!
        	I2C0->C1 |= (1 << 3);
        }

       if(index == length - 1){
            SendStop();
        }
        // Read Byte from Data Register into Array
       destination[index] = I2C0->D;
    }
}

void I2C_setup()
{
    // Enable Clock Gating for I2C module and Port
	SIM->SCGC4 |= 0x1 << 6;
	SIM->SCGC5 |= 0x1 << 11;

    // Setup Pin Mode for I2C
	PORTC->PCR[8] &= ~0x700;
	PORTC->PCR[9] &= ~0x700;
	PORTC->PCR[8] = 0x2 << 8;
	PORTC->PCR[9] = 0x2 << 8;

    // Write 0 to all I2C registers
	I2C0->A1 = 0;
	I2C0->S = 1 << 4 | 1 << 1;
	I2C0->D = 0;
	I2C0->C2 = 0;
	I2C0->RA = 0;
	I2C0->SMB = 0;
	I2C0->A2 = 0;
	I2C0->SLTH = 0;
	I2C0->SLTL = 0;

    // Write 0x50 to FLT register (clears all bits)
	I2C0->FLT = 0x50;

    // Set I2C Divider Register (Choose a clock frequency less than 100 KHz)
	I2C0->F = 0x2E;

    // Set bit to enable I2C Module
	I2C0->C1 = 1 << 7;
}
