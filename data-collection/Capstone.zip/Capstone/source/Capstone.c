/*
 * Copyright 2016-2024 NXP
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

/**
 * @file    Capstone.c
 * @brief   Application entry point.
 */
#include <stdio.h>
#include "board.h"
#include "peripherals.h"
#include "pin_mux.h"
#include "clock_config.h"
#include "MKL46Z4.h"
#include "fsl_debug_console.h"
#include "i2c.h"
/* TODO: insert other include files here. */

/* TODO: insert other definitions and declarations here. */

/*
 * Delay function
 */

void delay_ms(unsigned short delay_t)
{
    SIM->SCGC6 |= (1 << 24); // Clock Enable TPM0
    SIM->SOPT2 |= (0x2 << 24); // Set TPMSRC to OSCERCLK
    TPM0->CONF |= (0x1 << 17); // Stop on Overflow
    TPM0->SC = (0x1 << 7) | (0x07); // Reset Timer Overflow Flag, Set Prescaler 128
    TPM0->MOD = delay_t * 62 + delay_t/2; //

    TPM0->SC |= 0x01 << 3; // Start the clock!

    while(!(TPM0->SC & 0x80)){} // Wait until Overflow Flag
    return;
}

/*
 * @brief   Application entry point.
 */
int main(void)
{

    /* Init board hardware. */
    BOARD_InitBootPins();
    BOARD_InitBootClocks();
    BOARD_InitBootPeripherals();
#ifndef BOARD_INIT_DEBUG_CONSOLE_PERIPHERAL
    /* Init FSL debug console. */
    BOARD_InitDebugConsole();
#endif

    PRINTF("Hello World\r\n");

    bool ledState = false;
    SIM->SCGC5 |= 1<<12;
    PORTD->PCR[5] &= ~0x700;
    PORTD->PCR[5] |= 0x700 & (1 << 8);
    GPIOD->PDDR |= (1 << 5);

    /*----------Analog Input Setup----------*/
    SIM->SCGC6 |= 1<<27; // Clock Gating for ADC0
	SIM->SCGC5 |= 1<<13; // Clock gating for PORTE

	PORTE->PCR[16] &= ~0x700; // SET PTE16 MUX to 0

	ADC0->CFG1 = 0;
	ADC0->SC1[0] &= ~(1<<5);

	// Analog Calibrate
	ADC0->SC3 = 0x07; // Enable Maximum Hardware Averaging
	ADC0->SC3 |= 0x80; // Start Calibration

	// Wait for Calibration to Complete (either COCO or CALF)
	while(!(ADC0->SC1[0] & 0x80)){ }

	// Calibration Complete, write calibration registers.
	int cal_v = ADC0->CLP0 + ADC0->CLP1 + ADC0->CLP2 + ADC0->CLP3 + ADC0->CLP4 + ADC0->CLPS;
	cal_v = cal_v >> 1 | 0x8000;
	ADC0->PG = cal_v;

	ADC0->SC3 = 0; // Turn off Hardware Averaging
	/*----------End Analog Input Setup-----------*/

	// Setup I2C for Humidity and Velocity Sensor
	I2C_setup();

	/* Force the counter to be placed into memory. */
	volatile static int i = 0 ;

    /* Enter an infinite loop, just incrementing a counter. */
    while(1) {

    	// Get data from vibration sensor
    	ADC0->SC1[0] = 0x01; // Set Channel, starts conversion.
    	while(!(ADC0->SC1[0] & 0x80)){ }
    	int vibration = ADC0->R[0]; // Resets COCO
    	PRINTF("Vibration: %d, ", vibration);

    	// Get data from air velocity sensor
    	unsigned char buffer[6];
    	I2C_readBlock(0x28, buffer, 5);

    	unsigned int airVelocity =  buffer[1] << 8 | buffer[2];
    	unsigned int airVelocityInt = (airVelocity - 405) / 473;
    	unsigned int airVelocityDecimal = (((airVelocity - 405) % 473) * 100) / 473;
    	PRINTF("Air Velocity: %d.%02dm/s, ", airVelocityInt, airVelocityDecimal);
    	//PRINTF("Air Velocity: %d, ", airVelocity);

    	// Send conversion signal to temperature and humidity signal
    	I2C_writeByte(0x40, 0x40);

    	// Wait for conversion
    	delay_ms(10);

    	// Request humidity and temperature reads
    	I2C_writeByte(0x40, 0x0);

    	// Read device values
    	I2C_readBlock(0x40, buffer, 6);

    	unsigned long temperature = (buffer[0] << 8 | buffer[1]) * 165;
    	int tempInt = -40 + (temperature >> 16);
    	unsigned int tempDecimal = ((temperature & 0xFFFF) * 100) >> 16;

    	unsigned long humidity = (buffer[3] << 8 | buffer[4]) * 100;
    	int humidityInt = humidity >> 16;
    	unsigned int humidityDecimal = ((humidity & 0xFFFF) * 100) >> 16;

    	PRINTF("Temperature: %d.%02dC, ", tempInt, tempDecimal);
    	PRINTF("Humidity: %d.%02d%%\n", humidityInt, humidityDecimal);

    	i++;
        if (i % 100000 == 0) {
			ledState = !ledState;
			if(ledState) {
				GPIOD->PDOR |= (1<<5);
			}
			else {
			GPIOD->PDOR &= ~(1<<5);
			}
		}
    }
    return 0;
}
