/*
 * i2c.h
 *
 *  Created on: Mar 25, 2024
 *      Author: jacklusenhop
 */

#ifndef I2C_H_
#define I2C_H_

void I2C_writeByte(char register_address, char data);
void I2C_readBlock(unsigned char device_addr, unsigned char* destination, int length);
void I2C_setup();

#endif /* I2C_H_ */
