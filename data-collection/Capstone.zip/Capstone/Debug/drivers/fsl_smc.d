drivers/fsl_smc.o drivers/fsl_smc.d: ../drivers/fsl_smc.c \
 ../drivers/fsl_smc.h ../drivers/fsl_common.h \
 /Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/CMSIS/fsl_device_registers.h \
 /Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/CMSIS/MKL46Z4.h \
 /Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/CMSIS/core_cm0plus.h \
 /Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/CMSIS/cmsis_version.h \
 /Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/CMSIS/cmsis_compiler.h \
 /Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/CMSIS/cmsis_gcc.h \
 /Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/CMSIS/system_MKL46Z4.h \
 /Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/CMSIS/MKL46Z4_features.h \
 ../drivers/fsl_clock.h ../drivers/fsl_flash.h \
 ../drivers/fsl_ftfx_cache.h ../drivers/fsl_ftfx_controller.h \
 ../drivers/fsl_ftfx_features.h ../drivers/fsl_ftfx_adapter.h \
 ../drivers/fsl_ftfx_utilities.h ../drivers/fsl_ftfx_flash.h
../drivers/fsl_smc.h:
../drivers/fsl_common.h:
/Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/CMSIS/fsl_device_registers.h:
/Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/CMSIS/MKL46Z4.h:
/Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/CMSIS/core_cm0plus.h:
/Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/CMSIS/cmsis_version.h:
/Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/CMSIS/cmsis_compiler.h:
/Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/CMSIS/cmsis_gcc.h:
/Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/CMSIS/system_MKL46Z4.h:
/Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/CMSIS/MKL46Z4_features.h:
../drivers/fsl_clock.h:
../drivers/fsl_flash.h:
../drivers/fsl_ftfx_cache.h:
../drivers/fsl_ftfx_controller.h:
../drivers/fsl_ftfx_features.h:
../drivers/fsl_ftfx_adapter.h:
../drivers/fsl_ftfx_utilities.h:
../drivers/fsl_ftfx_flash.h:
