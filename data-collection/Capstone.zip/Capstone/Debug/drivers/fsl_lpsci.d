drivers/fsl_lpsci.o drivers/fsl_lpsci.d: ../drivers/fsl_lpsci.c \
 ../drivers/fsl_lpsci.h ../drivers/fsl_common.h \
 /Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/CMSIS/fsl_device_registers.h \
 /Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/CMSIS/MKL46Z4.h \
 /Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/CMSIS/core_cm0plus.h \
 /Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/CMSIS/cmsis_version.h \
 /Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/CMSIS/cmsis_compiler.h \
 /Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/CMSIS/cmsis_gcc.h \
 /Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/CMSIS/system_MKL46Z4.h \
 /Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/CMSIS/MKL46Z4_features.h \
 ../drivers/fsl_clock.h
../drivers/fsl_lpsci.h:
../drivers/fsl_common.h:
/Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/CMSIS/fsl_device_registers.h:
/Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/CMSIS/MKL46Z4.h:
/Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/CMSIS/core_cm0plus.h:
/Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/CMSIS/cmsis_version.h:
/Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/CMSIS/cmsis_compiler.h:
/Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/CMSIS/cmsis_gcc.h:
/Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/CMSIS/system_MKL46Z4.h:
/Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/CMSIS/MKL46Z4_features.h:
../drivers/fsl_clock.h:
