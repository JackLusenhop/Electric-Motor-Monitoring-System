source/i2c.o source/i2c.d: ../source/i2c.c \
 /Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/board/board.h \
 /Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/board/clock_config.h \
 /Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/drivers/fsl_common.h \
 /Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/CMSIS/fsl_device_registers.h \
 /Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/CMSIS/MKL46Z4.h \
 /Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/CMSIS/core_cm0plus.h \
 /Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/CMSIS/cmsis_version.h \
 /Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/CMSIS/cmsis_compiler.h \
 /Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/CMSIS/cmsis_gcc.h \
 /Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/CMSIS/system_MKL46Z4.h \
 /Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/CMSIS/MKL46Z4_features.h \
 /Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/drivers/fsl_clock.h \
 /Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/drivers/fsl_common.h \
 /Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/drivers/fsl_gpio.h \
 /Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/board/peripherals.h \
 /Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/drivers/fsl_port.h \
 /Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/drivers/fsl_i2c.h \
 /Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/board/pin_mux.h \
 /Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/board/clock_config.h \
 /Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/CMSIS/MKL46Z4.h \
 /Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/utilities/fsl_debug_console.h
/Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/board/board.h:
/Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/board/clock_config.h:
/Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/drivers/fsl_common.h:
/Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/CMSIS/fsl_device_registers.h:
/Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/CMSIS/MKL46Z4.h:
/Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/CMSIS/core_cm0plus.h:
/Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/CMSIS/cmsis_version.h:
/Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/CMSIS/cmsis_compiler.h:
/Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/CMSIS/cmsis_gcc.h:
/Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/CMSIS/system_MKL46Z4.h:
/Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/CMSIS/MKL46Z4_features.h:
/Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/drivers/fsl_clock.h:
/Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/drivers/fsl_common.h:
/Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/drivers/fsl_gpio.h:
/Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/board/peripherals.h:
/Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/drivers/fsl_port.h:
/Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/drivers/fsl_i2c.h:
/Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/board/pin_mux.h:
/Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/board/clock_config.h:
/Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/CMSIS/MKL46Z4.h:
/Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/utilities/fsl_debug_console.h:
