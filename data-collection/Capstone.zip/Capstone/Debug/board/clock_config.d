board/clock_config.o board/clock_config.d: ../board/clock_config.c \
 /Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/drivers/fsl_smc.h \
 /Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/drivers/fsl_common.h \
 /Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/CMSIS/fsl_device_registers.h \
 /Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/CMSIS/MKL46Z4.h \
 /Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/CMSIS/core_cm0plus.h \
 /Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/CMSIS/cmsis_version.h \
 /Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/CMSIS/cmsis_compiler.h \
 /Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/CMSIS/cmsis_gcc.h \
 /Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/CMSIS/system_MKL46Z4.h \
 /Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/CMSIS/MKL46Z4_features.h \
 /Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/drivers/fsl_clock.h \
 ../board/clock_config.h \
 /Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/drivers/fsl_common.h
/Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/drivers/fsl_smc.h:
/Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/drivers/fsl_common.h:
/Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/CMSIS/fsl_device_registers.h:
/Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/CMSIS/MKL46Z4.h:
/Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/CMSIS/core_cm0plus.h:
/Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/CMSIS/cmsis_version.h:
/Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/CMSIS/cmsis_compiler.h:
/Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/CMSIS/cmsis_gcc.h:
/Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/CMSIS/system_MKL46Z4.h:
/Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/CMSIS/MKL46Z4_features.h:
/Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/drivers/fsl_clock.h:
../board/clock_config.h:
/Users/jacklusenhop/Documents/MCUXpressoIDE_11.9.0_2144/workspace/Capstone/drivers/fsl_common.h:
